#include "MyException.h"

MyException::MyException(char* s)
{
    exc=s;
}

