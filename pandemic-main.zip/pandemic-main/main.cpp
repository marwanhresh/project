#include <iostream>
#include "City.hpp"
#include "Color.hpp"
#include "OperationsExpert.hpp"
#include "Virologist.hpp"
#include "Board.hpp"
#include <exception>
#include "FieldDoctor.hpp"
int main()
{

    return 0;
}
