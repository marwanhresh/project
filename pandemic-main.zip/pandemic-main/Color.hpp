
class Color
{
    public:
        Color();
        virtual ~Color();
    enum Colors{
        Blue,
        Black,
        Red,
        Yellow
    };
};
